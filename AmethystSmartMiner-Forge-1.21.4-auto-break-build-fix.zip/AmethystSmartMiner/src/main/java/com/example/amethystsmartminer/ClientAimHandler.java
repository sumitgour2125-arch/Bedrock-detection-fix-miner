package com.example.amethystsmartminer;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.client.event.RenderHighlightEvent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Map;

@Mod.EventBusSubscriber(modid = AmethystSmartMiner.MOD_ID, value = Dist.CLIENT)
public final class ClientAimHandler {
    private static boolean enabled = false;
    private static double reach = 5.0;
    private static final double MIN_REACH = 1.0;
    private static final double MAX_REACH = 8.0;
    // Fast, short snap while still smoothing the camera over a few client ticks.
    private static final float TURN_RATE_DEGREES_PER_TICK = 35.0f;
    private static boolean highlightEnabled = true;
    private static boolean autoBreakEnabled = false;
    private static boolean forcedAttack = false;
    private static final double POV_HALF_ANGLE_DEGREES = 70.0;
    private static final long REVISIT_DELAY_MS = 6500L;

    // Adjustable pause after the old target is broken. Default 0 = fastest possible
    // client-side reaction (the next client tick, normally within 50 ms).
    private static long switchDelayMs = 0L;
    private static final long MIN_SWITCH_DELAY_MS = 0L;
    private static final long MAX_SWITCH_DELAY_MS = 500L;
    private static final long SWITCH_DELAY_STEP_MS = 25L;
    private static long switchAfterMs = 0L;

    private static BlockPos lockedTarget = null;
    private static final Map<BlockPos, Long> recentlyMined = new HashMap<>();

    private ClientAimHandler() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;

        if (ClientKeys.TOGGLE.consumeClick()) {
            enabled = !enabled;
            lockedTarget = null;
            switchAfterMs = 0L;
            mc.player.displayClientMessage(Component.literal("Amethyst Aim Assist: " + (enabled ? "ON" : "OFF")), true);
        }
        if (ClientKeys.REACH_DOWN.consumeClick()) {
            reach = Math.max(MIN_REACH, reach - 0.5);
            mc.player.displayClientMessage(Component.literal(String.format("Aim reach: %.1f blocks", reach)), true);
        }
        if (ClientKeys.REACH_UP.consumeClick()) {
            reach = Math.min(MAX_REACH, reach + 0.5);
            mc.player.displayClientMessage(Component.literal(String.format("Aim reach: %.1f blocks", reach)), true);
        }
        if (ClientKeys.SWITCH_FASTER.consumeClick()) {
            switchDelayMs = Math.max(MIN_SWITCH_DELAY_MS, switchDelayMs - SWITCH_DELAY_STEP_MS);
            showSwitchDelay(mc);
        }
        if (ClientKeys.SWITCH_SLOWER.consumeClick()) {
            switchDelayMs = Math.min(MAX_SWITCH_DELAY_MS, switchDelayMs + SWITCH_DELAY_STEP_MS);
            showSwitchDelay(mc);
        }
        if (ClientKeys.SWITCH_RESET.consumeClick()) {
            switchDelayMs = 0L;
            showSwitchDelay(mc);
        }
        if (ClientKeys.HIGHLIGHT_TOGGLE.consumeClick()) {
            highlightEnabled = !highlightEnabled;
            mc.player.displayClientMessage(Component.literal("Block highlight: " + (highlightEnabled ? "ON" : "OFF")), true);
        }
        if (ClientKeys.AUTO_BREAK_TOGGLE.consumeClick()) {
            autoBreakEnabled = !autoBreakEnabled;
            mc.player.displayClientMessage(Component.literal("Auto break: " + (autoBreakEnabled ? "ON (requires aim assist)" : "OFF")), true);
        }

        // Hold the normal attack binding while auto-break is enabled. Vanilla's normal
        // block-damage loop then handles hardness, tool speed, drops, and server packets.
        boolean shouldForceAttack = enabled && autoBreakEnabled;
        if (shouldForceAttack) {
            mc.options.keyAttack.setDown(true);
            forcedAttack = true;
        } else if (forcedAttack) {
            mc.options.keyAttack.setDown(false);
            forcedAttack = false;
        }

        if (!enabled || (!mc.options.keyAttack.isDown() && !autoBreakEnabled)) {
            lockedTarget = null;
            switchAfterMs = 0L;
            return;
        }

        Player player = mc.player;
        Level level = mc.level;
        long now = System.currentTimeMillis();
        recentlyMined.entrySet().removeIf(entry -> entry.getValue() <= now);

        // Keep aiming at the current amethyst target. As soon as the client sees that
        // the block is gone/replaced, schedule the next target using the chosen delay.
        if (lockedTarget != null && isAmethyst(level, lockedTarget)) {
            double lockedDistance = Vec3.atCenterOf(lockedTarget).distanceTo(player.getEyePosition());
            if (lockedDistance <= reach) {
                aimAt(player, lockedTarget);
                return;
            }
            lockedTarget = null;
            switchAfterMs = now;
        } else if (lockedTarget != null) {
            recentlyMined.put(lockedTarget.immutable(), now + REVISIT_DELAY_MS);
            lockedTarget = null;
            switchAfterMs = now + switchDelayMs;
        }

        // A delay of zero selects a new target immediately on this same tick.
        if (now < switchAfterMs) return;

        BlockPos next = findTarget(player, level, now, false);
        if (next == null) next = findTarget(player, level, now, true);
        if (next != null) {
            lockedTarget = next.immutable();
            switchAfterMs = 0L;
            aimAt(player, lockedTarget);
        }
    }

    // Replace the vanilla dark outline with a cyan outline around the actual locked target.
    // This follows the aim target rather than whichever block happened to be hit last.
    @SubscribeEvent
    public static void onBlockHighlight(RenderHighlightEvent.Block event) {
        Minecraft mc = Minecraft.getInstance();
        if (!enabled || !highlightEnabled || mc.level == null || lockedTarget == null) return;
        if (!isAmethyst(mc.level, lockedTarget)) return;

        event.setCanceled(true);
        BlockPos target = lockedTarget.immutable();
        var state = mc.level.getBlockState(target);
        var shape = state.getShape(mc.level, target);
        if (shape.isEmpty()) return;

        Vec3 camera = event.getCamera().getPosition();
        PoseStack pose = event.getPoseStack();
        pose.pushPose();
        pose.translate(-camera.x, -camera.y, -camera.z);
        AABB bounds = shape.bounds().move(target).inflate(0.002);
        LevelRenderer.renderLineBox(pose, event.getMultiBufferSource().getBuffer(RenderType.lines()),
                bounds, 0.0F, 1.0F, 1.0F, 1.0F);
        pose.popPose();
    }

    private static void showSwitchDelay(Minecraft mc) {
        String speed = switchDelayMs == 0L ? "INSTANT" : switchDelayMs + " ms delay";
        mc.player.displayClientMessage(Component.literal("Block switch: " + speed), true);
    }

    private static BlockPos findTarget(Player player, Level level, long now, boolean allowRecentlyMined) {
        Vec3 eye = player.getEyePosition();
        Vec3 look = player.getLookAngle().normalize();
        double maxDistance = reach;
        double minDot = Math.cos(Math.toRadians(POV_HALF_ANGLE_DEGREES));
        int radius = Mth.ceil((float) maxDistance);
        BlockPos origin = player.blockPosition();
        BlockPos best = null;
        double bestDistance = Double.MAX_VALUE;

        for (BlockPos pos : BlockPos.betweenClosed(origin.offset(-radius, -radius, -radius),
                origin.offset(radius, radius, radius))) {
            if (!isAmethyst(level, pos)) continue;
            BlockPos candidate = pos.immutable();
            Long cooldown = recentlyMined.get(candidate);
            if (!allowRecentlyMined && cooldown != null && cooldown > now) continue;

            Vec3 center = Vec3.atCenterOf(candidate);
            Vec3 delta = center.subtract(eye);
            double distance = delta.length();
            if (distance < 0.05 || distance > maxDistance) continue;
            if (delta.normalize().dot(look) < minDot) continue;

            BlockHitResult sight = level.clip(new ClipContext(eye, center,
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
            if (sight.getType() != HitResult.Type.BLOCK || !sight.getBlockPos().equals(candidate)) continue;

            if (distance < bestDistance) {
                bestDistance = distance;
                best = candidate;
            }
        }
        return best;
    }

    private static boolean isAmethyst(Level level, BlockPos pos) {
        var state = level.getBlockState(pos);
        // Only target breakable growths. Budding amethyst and full amethyst blocks
        // are intentionally excluded so auto-break cannot get stuck on them.
        return state.is(Blocks.AMETHYST_CLUSTER)
                || state.is(Blocks.LARGE_AMETHYST_BUD)
                || state.is(Blocks.MEDIUM_AMETHYST_BUD)
                || state.is(Blocks.SMALL_AMETHYST_BUD);
    }

    private static void aimAt(Player player, BlockPos target) {
        Vec3 delta = Vec3.atCenterOf(target).subtract(player.getEyePosition());
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float targetYaw = (float) (Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float targetPitch = (float) -Math.toDegrees(Math.atan2(delta.y, horizontal));
        float yawDifference = Mth.wrapDegrees(targetYaw - player.getYRot());
        float pitchDifference = targetPitch - player.getXRot();
        player.setYRot(player.getYRot() + Mth.clamp(yawDifference,
                -TURN_RATE_DEGREES_PER_TICK, TURN_RATE_DEGREES_PER_TICK));
        player.setXRot(player.getXRot() + Mth.clamp(pitchDifference,
                -TURN_RATE_DEGREES_PER_TICK, TURN_RATE_DEGREES_PER_TICK));
    }
}
