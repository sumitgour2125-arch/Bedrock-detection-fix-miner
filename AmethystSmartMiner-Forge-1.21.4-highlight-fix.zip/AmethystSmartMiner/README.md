# Amethyst Smart Miner (Forge 1.21.4)

Client-side amethyst target aim assist with configurable reach, fast target switching, and a cyan target outline.

## Controls
- **G**: Toggle aim assist
- **[ / ]**: Decrease / increase target reach
- **= / -**: Decrease / increase delay before switching targets
- **\\**: Reset switch delay to instant
- **H**: Toggle cyan target highlight
- **J**: Toggle automatic amethyst cluster breaking (requires aim assist to be ON)

The aim now turns at up to 35 degrees per client tick (previously 7), so it snaps between targets much faster while retaining a short smooth transition. The switch delay still defaults to 0 ms. The highlight follows the locked amethyst target and uses a cyan outline. Auto-break holds Minecraft’s normal attack input while aim assist is enabled, allowing vanilla block-damage handling to break reachable amethyst clusters automatically. Budding amethyst and full amethyst blocks are excluded because they are not breakable targets.

## Build
Use Java 21 and Gradle with ForgeGradle. From this directory run `gradle build`. The output JAR is in `build/libs/`.
