package com.example.amethystsmartminer;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.api.distmarker.Dist;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = AmethystSmartMiner.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientKeys {
    public static final KeyMapping TOGGLE = new KeyMapping(
            "key.amethystsmartminer.toggle", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_G,
            "key.categories.amethystsmartminer");
    public static final KeyMapping REACH_DOWN = new KeyMapping(
            "key.amethystsmartminer.reach_down", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_BRACKET,
            "key.categories.amethystsmartminer");
    public static final KeyMapping REACH_UP = new KeyMapping(
            "key.amethystsmartminer.reach_up", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_BRACKET,
            "key.categories.amethystsmartminer");

    // Lower delay means faster target switching. Zero means switch on the first client tick
    // that observes the previous target has stopped being an amethyst block.
    public static final KeyMapping SWITCH_FASTER = new KeyMapping(
            "key.amethystsmartminer.switch_faster", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_EQUAL,
            "key.categories.amethystsmartminer");
    public static final KeyMapping SWITCH_SLOWER = new KeyMapping(
            "key.amethystsmartminer.switch_slower", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_MINUS,
            "key.categories.amethystsmartminer");
    public static final KeyMapping SWITCH_RESET = new KeyMapping(
            "key.amethystsmartminer.switch_reset", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_BACKSLASH,
            "key.categories.amethystsmartminer");

    public static final KeyMapping HIGHLIGHT_TOGGLE = new KeyMapping(
            "key.amethystsmartminer.highlight_toggle", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_H,
            "key.categories.amethystsmartminer");
    public static final KeyMapping AUTO_BREAK_TOGGLE = new KeyMapping(
            "key.amethystsmartminer.auto_break_toggle", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_J,
            "key.categories.amethystsmartminer");

    private ClientKeys() {}

    @SubscribeEvent
    public static void register(RegisterKeyMappingsEvent event) {
        event.register(TOGGLE);
        event.register(REACH_DOWN);
        event.register(REACH_UP);
        event.register(SWITCH_FASTER);
        event.register(SWITCH_SLOWER);
        event.register(SWITCH_RESET);
        event.register(HIGHLIGHT_TOGGLE);
        event.register(AUTO_BREAK_TOGGLE);
    }
}
