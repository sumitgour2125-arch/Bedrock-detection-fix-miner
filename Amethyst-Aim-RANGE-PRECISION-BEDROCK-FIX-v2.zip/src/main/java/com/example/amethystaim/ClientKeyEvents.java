package com.example.amethystaim;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = AmethystAim.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientKeyEvents {
    public static final KeyMapping TOGGLE_AIM = new KeyMapping(
            "key.amethystaim.toggle", InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_G, "key.categories.amethystaim");
    public static final KeyMapping INCREASE_RANGE = new KeyMapping(
            "key.amethystaim.range_up", InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_RIGHT_BRACKET, "key.categories.amethystaim");
    public static final KeyMapping DECREASE_RANGE = new KeyMapping(
            "key.amethystaim.range_down", InputConstants.Type.KEYSYM,
            GLFW.GLFW_KEY_LEFT_BRACKET, "key.categories.amethystaim");

    private ClientKeyEvents() {}

    @SubscribeEvent
    public static void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(TOGGLE_AIM);
        event.register(INCREASE_RANGE);
        event.register(DECREASE_RANGE);
    }
}
