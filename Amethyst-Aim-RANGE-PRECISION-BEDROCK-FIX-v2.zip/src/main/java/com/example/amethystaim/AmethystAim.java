package com.example.amethystaim;

import net.minecraftforge.fml.common.Mod;

@Mod(AmethystAim.MODID)
public final class AmethystAim {
    public static final String MODID = "amethystaim";

    public AmethystAim() {
        // Client-only behavior is registered by the client event subscribers.
    }
}
