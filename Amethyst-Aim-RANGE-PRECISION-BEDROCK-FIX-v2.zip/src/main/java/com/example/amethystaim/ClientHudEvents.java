package com.example.amethystaim;

// HUD status overlay disabled for Forge 1.21.4 compatibility.
// The aiming and target-selection logic is implemented in ClientTickEvents.
public final class ClientHudEvents {
    private ClientHudEvents() {}
}
