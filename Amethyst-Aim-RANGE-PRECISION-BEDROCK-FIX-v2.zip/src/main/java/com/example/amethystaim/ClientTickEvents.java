package com.example.amethystaim;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.HitResult;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

@Mod.EventBusSubscriber(modid = AmethystAim.MODID, value = Dist.CLIENT)
public final class ClientTickEvents {
    private static final int MIN_SEARCH_RADIUS = 2;
    private static final int MAX_SEARCH_RADIUS = 64;
    private static final int RANGE_STEP = 2;

    // Re-scan every tick so invalid or obstructed targets are replaced immediately.
    private static final int SCAN_EVERY_TICKS = 1;
    private static final float TURN_SMOOTHING = 0.45F;
    // Snap the final fraction of a degree so smoothing does not asymptotically stop short.
    private static final float AIM_SNAP_DEGREES = 0.65F;

    // Wide enough to find targets around the crosshair, but avoids snapping behind the player.
    private static final double MIN_VIEW_DOT = 0.20D; // about a 78 degree cone
    private static final int RECENT_TARGET_MEMORY_TICKS = 40;
    private static final double RECENT_TARGET_PENALTY = 9.0D;

    private static boolean enabled = false;
    private static int searchRadius = 12;
    private static int tickCounter = 0;
    private static long activeTicks = 0;
    private static BlockPos target = null;
    private static final Map<BlockPos, Long> recentlyTargeted = new HashMap<>();

    private ClientTickEvents() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;

        Minecraft mc = Minecraft.getInstance();
        while (ClientKeyEvents.TOGGLE_AIM.consumeClick()) {
            enabled = !enabled;
            target = null;
            recentlyTargeted.clear();
        }
        while (ClientKeyEvents.INCREASE_RANGE.consumeClick()) {
            searchRadius = Math.min(MAX_SEARCH_RADIUS, searchRadius + RANGE_STEP);
            target = null;
        }
        while (ClientKeyEvents.DECREASE_RANGE.consumeClick()) {
            searchRadius = Math.max(MIN_SEARCH_RADIUS, searchRadius - RANGE_STEP);
            target = null;
        }

        if (!enabled || mc.player == null || mc.level == null || mc.screen != null) return;

        activeTicks++;
        if (target != null && (!mc.level.getBlockState(target).is(Blocks.AMETHYST_BLOCK)
                || !isVisibleAmethyst(mc, target))) {
            // The server may replace a mined amethyst with bedrock, or another block
            // may obstruct the line of sight. Drop the stale target immediately.
            recentlyTargeted.put(target, activeTicks);
            target = null;
        }
        if (target == null && ++tickCounter >= SCAN_EVERY_TICKS) {
            tickCounter = 0;
            target = findBestAmethyst(mc);
            if (target != null) recentlyTargeted.put(target, activeTicks);
        }

        if (target != null && mc.level.getBlockState(target).is(Blocks.AMETHYST_BLOCK)) {
            aimAt(mc, Vec3.atCenterOf(target));
        } else {
            if (target != null) recentlyTargeted.put(target, activeTicks);
            target = null;
        }

        // Expire old entries so the map stays small and targets become eligible again.
        Iterator<Map.Entry<BlockPos, Long>> it = recentlyTargeted.entrySet().iterator();
        while (it.hasNext()) {
            if (activeTicks - it.next().getValue() > RECENT_TARGET_MEMORY_TICKS) it.remove();
        }
    }

    private static boolean isVisibleAmethyst(Minecraft mc, BlockPos pos) {
        if (mc.player == null || mc.level == null
                || !mc.level.getBlockState(pos).is(Blocks.AMETHYST_BLOCK)) return false;
        Vec3 eyes = mc.player.getEyePosition();
        Vec3 center = Vec3.atCenterOf(pos);
        BlockHitResult hit = mc.level.clip(new ClipContext(
                eyes, center, ClipContext.Block.COLLIDER,
                ClipContext.Fluid.NONE, mc.player));
        return hit.getType() == HitResult.Type.BLOCK && hit.getBlockPos().equals(pos);
    }

    private static BlockPos findBestAmethyst(Minecraft mc) {
        Vec3 eyes = mc.player.getEyePosition();
        Vec3 look = mc.player.getViewVector(1.0F).normalize();
        BlockPos origin = mc.player.blockPosition();
        BlockPos best = null;
        double bestScore = Double.POSITIVE_INFINITY;
        double maxDistanceSqr = (double) searchRadius * searchRadius;

        for (BlockPos pos : BlockPos.betweenClosed(
                origin.offset(-searchRadius, -searchRadius, -searchRadius),
                origin.offset(searchRadius, searchRadius, searchRadius))) {
            if (!mc.level.getBlockState(pos).is(Blocks.AMETHYST_BLOCK)) continue;

            Vec3 center = Vec3.atCenterOf(pos);
            Vec3 toBlock = center.subtract(eyes);
            double distanceSqr = toBlock.lengthSqr();
            if (distanceSqr < 0.01D || distanceSqr > maxDistanceSqr) continue;

            // Do not lock onto blocks hidden behind bedrock or other solid blocks.
            if (!isVisibleAmethyst(mc, pos)) continue;

            Vec3 direction = toBlock.normalize();
            double viewDot = look.dot(direction);
            if (viewDot < MIN_VIEW_DOT) continue;

            // Prefer blocks close to the current drill view, then nearer blocks.
            // Recent targets receive a temporary penalty to encourage mining spread.
            double angleCost = (1.0D - viewDot) * 12.0D;
            double distanceCost = Math.sqrt(distanceSqr) * 0.12D;
            long lastSeen = recentlyTargeted.getOrDefault(pos, Long.MIN_VALUE / 2);
            double recencyCost = activeTicks - lastSeen <= RECENT_TARGET_MEMORY_TICKS
                    ? RECENT_TARGET_PENALTY : 0.0D;
            double currentTargetBonus = pos.equals(target) ? -2.0D : 0.0D;
            double score = angleCost + distanceCost + recencyCost + currentTargetBonus;

            if (score < bestScore) {
                bestScore = score;
                best = pos.immutable();
            }
        }
        return best;
    }

    private static void aimAt(Minecraft mc, Vec3 destination) {
        Vec3 eyes = mc.player.getEyePosition();
        double dx = destination.x - eyes.x;
        double dy = destination.y - eyes.y;
        double dz = destination.z - eyes.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);

        float wantedYaw = (float) (Mth.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0F;
        float wantedPitch = (float) (-(Mth.atan2(dy, horizontal) * (180.0 / Math.PI)));

        float yawDelta = Mth.wrapDegrees(wantedYaw - mc.player.getYRot());
        float pitchDelta = wantedPitch - mc.player.getXRot();

        // Smooth most of the turn, but finish precisely instead of approaching the
        // target angle forever (the old fixed multiplier always stopped short).
        float nextYaw = Math.abs(yawDelta) <= AIM_SNAP_DEGREES
                ? wantedYaw : mc.player.getYRot() + yawDelta * TURN_SMOOTHING;
        float nextPitch = Math.abs(pitchDelta) <= AIM_SNAP_DEGREES
                ? wantedPitch : mc.player.getXRot() + pitchDelta * TURN_SMOOTHING;
        mc.player.setYRot(nextYaw);
        mc.player.setXRot(Mth.clamp(nextPitch, -90.0F, 90.0F));
    }

    public static boolean isEnabled() { return enabled; }
    public static int getSearchRadius() { return searchRadius; }
}
