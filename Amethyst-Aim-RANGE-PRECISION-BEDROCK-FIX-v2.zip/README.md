# Amethyst Aim — Forge 1.21.4

A client-side aiming helper that smoothly turns the player's view toward visible vanilla Amethyst Blocks.

## Controls
- **G**: toggle aim assist on/off.
- **]**: increase target/mining search range by 2 blocks.
- **[**: decrease target/mining search range by 2 blocks.
- Adjustable range: **2–64 blocks** (default: 12).
- Keys can be rebound in **Options → Controls → Amethyst Aim**.

The range is the maximum distance at which the mod searches for an Amethyst Block to aim at. This mod does **not** automatically break or mine blocks; the player still mines normally.

## Fixes in this build
- Drops a target as soon as it is no longer an Amethyst Block (for example, after the server replaces it with bedrock).
- Checks line of sight so it will not keep aiming at an Amethyst Block hidden behind bedrock or another blocking block.
- Smoothly turns toward the exact block center and snaps the final tiny angle difference, avoiding the old behavior where the aim eased to a stop just short of the target.
- Re-scans every tick for a valid replacement target.

## Build
Targets Minecraft **1.21.4**, Forge **54.1.0**, and Java **21**. Run `gradle build`; the JAR is created in `build/libs/`.

This ZIP contains the Gradle source project, not a precompiled JAR. It does not automatically mine blocks.
