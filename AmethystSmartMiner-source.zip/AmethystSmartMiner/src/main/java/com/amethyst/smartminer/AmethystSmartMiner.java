package com.amethyst.smartminer;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.loading.FMLPaths;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

@Mod(AmethystSmartMiner.MODID)
public class AmethystSmartMiner {
    public static final String MODID = "amethystsmartminer";

    private static final double MIN_REACH = 4.0;
    private static final double MAX_REACH = 20.0;

    /** Search radius in blocks (4 - 20). Change in game with the Reach + / Reach - keys. */
    private double reach = 8.0;

    private KeyMapping toggleKey;
    private KeyMapping reachUpKey;
    private KeyMapping reachDownKey;

    private boolean enabled = false;
    private boolean weHoldAttack = false;
    private BlockPos target = null;
    private int scanCooldown = 0;

    // Vanilla's "wait 5 ticks after breaking a block" counter (found by reflection, optional).
    private Field delayField = null;
    private boolean delayNameTried = false;
    private int delayLearnTries = 0;

    public AmethystSmartMiner(FMLJavaModLoadingContext context) {
        loadConfig();
        context.getModEventBus().addListener(this::onRegisterKeys);
        MinecraftForge.EVENT_BUS.register(this);
    }

    // ---------------------------------------------------------------- setup

    private void onRegisterKeys(RegisterKeyMappingsEvent event) {
        toggleKey = new KeyMapping("key.amethystsmartminer.toggle",
                InputConstants.Type.KEYSYM, InputConstants.KEY_K, "key.categories.misc");
        reachUpKey = new KeyMapping("key.amethystsmartminer.reach_up",
                InputConstants.Type.KEYSYM, 93 /* ] */, "key.categories.misc");
        reachDownKey = new KeyMapping("key.amethystsmartminer.reach_down",
                InputConstants.Type.KEYSYM, 91 /* [ */, "key.categories.misc");
        event.register(toggleKey);
        event.register(reachUpKey);
        event.register(reachDownKey);
    }

    private static Path cfgPath() {
        return FMLPaths.CONFIGDIR.get().resolve("amethystsmartminer.txt");
    }

    private void loadConfig() {
        try {
            Path p = cfgPath();
            if (Files.exists(p)) {
                reach = Mth.clamp(Double.parseDouble(Files.readString(p).trim()), MIN_REACH, MAX_REACH);
            }
        } catch (Exception ignored) {
        }
    }

    private void saveConfig() {
        try {
            Files.writeString(cfgPath(), Double.toString(reach));
        } catch (Exception ignored) {
        }
    }

    // ---------------------------------------------------------------- events

    /** Runs every tick: keybinds. */
    @SubscribeEvent
    public void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;

        if (toggleKey != null) {
            while (toggleKey.consumeClick()) {
                enabled = !enabled;
                target = null;
                scanCooldown = 0;
                if (player != null) {
                    player.displayClientMessage(Component.literal("Amethyst Miner: "
                            + (enabled ? "ON (reach " + (int) reach + ")" : "OFF")), true);
                }
            }
            while (reachUpKey.consumeClick()) changeReach(player, +1.0);
            while (reachDownKey.consumeClick()) changeReach(player, -1.0);
        }
        update(mc);
    }

    /** Runs at the start of EVERY rendered frame, so a broken block is noticed within one frame. */
    @SubscribeEvent
    public void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase != TickEvent.Phase.START) return;
        update(Minecraft.getInstance());
    }

    private void changeReach(LocalPlayer player, double delta) {
        reach = Mth.clamp(reach + delta, MIN_REACH, MAX_REACH);
        target = null;
        scanCooldown = 0;
        saveConfig();
        if (player != null) {
            player.displayClientMessage(Component.literal("Amethyst Miner reach: " + (int) reach), true);
        }
    }

    // ---------------------------------------------------------------- core

    private void update(Minecraft mc) {
        LocalPlayer player = mc.player;
        ClientLevel level = mc.level;
        if (!enabled || player == null || level == null || mc.gameMode == null || mc.screen != null) {
            releaseAttack(mc);
            return;
        }

        Vec3 eye = player.getEyePosition();
        double interact = player.blockInteractionRange();

        // Is our current target still there?
        boolean justBroke = false;
        Vec3 aim = null;
        if (target != null) {
            BlockState st = level.getBlockState(target);
            if (isAmethyst(st)) {
                Vec3 p = visiblePoint(level, player, eye, target, st, reach);
                if (p != null && p.distanceTo(eye) <= interact) {
                    aim = p;
                }
            } else {
                justBroke = true;
            }
        }

        if (justBroke) {
            learnDelayField(mc, player);
        }
        clearDestroyDelay(mc);

        if (aim == null) {
            if (justBroke) scanCooldown = 0; // react immediately after a break
            target = null;
            if (scanCooldown > 0) {
                scanCooldown--;
                releaseAttack(mc);
                return;
            }

            // Collect candidates cheaply, sort by "smallest turn", then ray-test in order.
            Vec3 look = player.getLookAngle();
            BlockPos base = player.blockPosition();
            int r = (int) Math.ceil(reach);
            double reachSq = (reach + 1.0) * (reach + 1.0);
            List<Cand> cands = new ArrayList<>();
            for (int dx = -r; dx <= r; dx++) {
                for (int dy = -r; dy <= r + 1; dy++) {
                    for (int dz = -r; dz <= r; dz++) {
                        BlockPos pos = base.offset(dx, dy, dz);
                        BlockState st = level.getBlockState(pos);
                        if (!isAmethyst(st)) continue;
                        Vec3 dir = new Vec3(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5).subtract(eye);
                        double distSq = dir.lengthSqr();
                        if (distSq > reachSq || distSq < 1.0E-6) continue;
                        double dist = Math.sqrt(distSq);
                        double score = (1.0 - look.dot(dir.scale(1.0 / dist))) * 10.0 + dist * 0.05;
                        if (dist > interact) score += 1000.0; // blocks you can really hit come first
                        cands.add(new Cand(pos.immutable(), score));
                    }
                }
            }
            cands.sort((a, b) -> Double.compare(a.score, b.score));

            for (Cand c : cands) {
                BlockState st = level.getBlockState(c.pos);
                Vec3 p = visiblePoint(level, player, eye, c.pos, st, reach);
                if (p != null) {
                    target = c.pos;
                    aim = p;
                    break;
                }
            }

            if (target == null || aim == null) {
                scanCooldown = 4;
                releaseAttack(mc);
                return;
            }
            if (aim.distanceTo(eye) > interact) {
                scanCooldown = 6; // only far blocks exist: aim at it, don't rescan every frame
            }
        }

        lookAt(player, eye, aim);

        if (aim.distanceTo(eye) <= interact) {
            mc.options.keyAttack.setDown(true);
            weHoldAttack = true;
        } else {
            releaseAttack(mc); // out of the server's real reach: walk closer
        }
    }

    private static final class Cand {
        final BlockPos pos;
        final double score;

        Cand(BlockPos pos, double score) {
            this.pos = pos;
            this.score = score;
        }
    }

    private void releaseAttack(Minecraft mc) {
        if (weHoldAttack) {
            mc.options.keyAttack.setDown(false);
            weHoldAttack = false;
        }
    }

    // ---------------------------------------------------------------- break-delay removal

    private void clearDestroyDelay(Minecraft mc) {
        try {
            if (delayField == null && !delayNameTried) {
                delayNameTried = true;
                try {
                    Field f = MultiPlayerGameMode.class.getDeclaredField("destroyDelay");
                    f.setAccessible(true);
                    delayField = f;
                } catch (Throwable ignored) {
                }
            }
            if (delayField != null && mc.gameMode != null) {
                delayField.setInt(mc.gameMode, 0);
            }
        } catch (Throwable ignored) {
        }
    }

    /** Fallback when field names are obfuscated: find the int that just became 1..5 after a break. */
    private void learnDelayField(Minecraft mc, LocalPlayer player) {
        if (delayField != null || delayLearnTries > 30 || mc.gameMode == null) return;
        delayLearnTries++;
        try {
            int sel = player.getInventory().selected;
            Field found = null;
            int n = 0;
            for (Field f : MultiPlayerGameMode.class.getDeclaredFields()) {
                if (f.getType() != int.class || Modifier.isStatic(f.getModifiers())) continue;
                f.setAccessible(true);
                int v = f.getInt(mc.gameMode);
                if (v >= 1 && v <= 5 && v != sel) {
                    found = f;
                    n++;
                }
            }
            if (n == 1) delayField = found;
        } catch (Throwable ignored) {
        }
    }

    // ---------------------------------------------------------------- helpers

    private static boolean isAmethyst(BlockState s) {
        return s.is(Blocks.AMETHYST_BLOCK)
                || s.is(Blocks.AMETHYST_CLUSTER)
                || s.is(Blocks.LARGE_AMETHYST_BUD)
                || s.is(Blocks.MEDIUM_AMETHYST_BUD)
                || s.is(Blocks.SMALL_AMETHYST_BUD);
    }

    /** Returns a point on the block that you can actually see from your eyes, or null. */
    private static Vec3 visiblePoint(ClientLevel level, LocalPlayer player, Vec3 eye,
                                     BlockPos pos, BlockState st, double maxDist) {
        VoxelShape shape = st.getShape(level, pos);
        if (shape.isEmpty()) return null;
        AABB bb = shape.bounds().move(pos);
        Vec3 c = bb.getCenter();
        Vec3[] pts = new Vec3[] {
                c,
                new Vec3(bb.minX, c.y, c.z), new Vec3(bb.maxX, c.y, c.z),
                new Vec3(c.x, bb.minY, c.z), new Vec3(c.x, bb.maxY, c.z),
                new Vec3(c.x, c.y, bb.minZ), new Vec3(c.x, c.y, bb.maxZ)
        };
        for (Vec3 p : pts) {
            Vec3 dir = p.subtract(eye);
            double dist = dir.length();
            if (dist > maxDist || dist < 1.0E-4) continue;
            Vec3 end = p.add(dir.scale(0.4 / dist));
            BlockHitResult hit = level.clip(new ClipContext(eye, end,
                    ClipContext.Block.OUTLINE, ClipContext.Fluid.NONE, player));
            if (hit.getType() == HitResult.Type.BLOCK && hit.getBlockPos().equals(pos)) {
                return p;
            }
        }
        return null;
    }

    private static void lookAt(LocalPlayer player, Vec3 eye, Vec3 p) {
        double dx = p.x - eye.x;
        double dy = p.y - eye.y;
        double dz = p.z - eye.z;
        double horiz = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Mth.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0F;
        float pitch = Mth.clamp((float) -(Mth.atan2(dy, horiz) * (180.0 / Math.PI)), -90.0F, 90.0F);
        player.setYRot(yaw);
        player.setXRot(pitch);
        player.setYHeadRot(yaw);
        player.yRotO = yaw;
        player.xRotO = pitch;
    }
}
